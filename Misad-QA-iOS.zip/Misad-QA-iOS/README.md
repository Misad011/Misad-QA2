# Misad QA — iOS (IPA)

Capacitor wrapper around the offline Misad QA web app (QAV3), with the Misad QA logo, app icon and the
animated launch screen (**Misad — Programmer**, **Eko — Designer**).

App id: `com.misad.qa` · Name: **Misad QA**

> **Important about iOS:** Apple only runs apps that are signed. Building the `.ipa` needs macOS + Xcode, which
> this project does for you on GitHub's free Mac runners. The IPA it produces is **unsigned**; you sign it when
> you install it (see "Installing"). There is no way around Apple's signing for any iOS app.

## Option A — no Mac needed: let GitHub build the IPA

1. Create a new **private** GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo → **Actions** → **Build iOS IPA (unsigned)** → **Run workflow** (it also runs on every push).
3. After ~10–15 minutes download the artifact **MisadQA-ipa** → unzip → `MisadQA-unsigned.ipa`.

## Installing the IPA

* **Free Apple ID (testing, expires every 7 days):** use **Sideloadly** or **AltStore** (Windows/Mac). They sign the
  IPA with your Apple ID and install it on your iPhone.
* **Apple Developer Program ($99/yr):** sign in Xcode (or with your own cert/profile) for TestFlight / App Store.
* **Your own Mac:** run the steps below and press ▶ in Xcode with your iPhone selected; Xcode signs it automatically.

## Option B — build on your own Mac

Requirements: macOS, Xcode (from the App Store), Node 20+, CocoaPods (`sudo gem install cocoapods`).

```bash
npm install
npm run setup          # creates ios/, applies the icon + launch screen, syncs the web app
npm run open           # opens Xcode → choose your Team under Signing & Capabilities → Run / Archive
```

## Changing the app

The whole app is `www/index.html`. After editing run `npx cap sync ios` and rebuild.
Data stays on the device (IndexedDB), same as the web version: import your TXT/JSON files from the **Knowledge** tab.
Exports (knowledge/settings JSON) open the iOS share sheet (Save to Files, AirDrop…) instead of a browser download.
