// Applies the Misad QA icon + launch screen to the native project that `npx cap add <platform>` generates.
// Usage: node scripts/apply-native-assets.mjs android|ios
import fs from "node:fs";
import path from "node:path";

const platform = process.argv[2];
const R = (...p) => path.join(process.cwd(), ...p);
const copy = (src, dst) => { fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.copyFileSync(src, dst); };
const walk = (dir, fn) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
  const p = path.join(dir, e.name); e.isDirectory() ? walk(p, fn) : fn(p); } };

if (platform === "android") {
  const res = R("android", "app", "src", "main", "res");
  if (!fs.existsSync(res)) { console.error("android/ not found - run `npx cap add android` first"); process.exit(1); }

  // 1) launcher icons (legacy square + round + adaptive foreground)
  const src = R("resources", "android");
  for (const d of fs.readdirSync(src)) {
    if (!d.startsWith("mipmap-")) continue;
    for (const f of fs.readdirSync(path.join(src, d))) {
      copy(path.join(src, d, f), path.join(res, d, f));
      const webp = path.join(res, d, f.replace(/\.png$/, ".webp"));   // avoid duplicate-resource errors
      if (fs.existsSync(webp)) fs.rmSync(webp);
    }
  }
  fs.mkdirSync(path.join(res, "values"), { recursive: true });
  fs.writeFileSync(path.join(res, "values", "ic_launcher_background.xml"),
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#6366F1</color>\n</resources>\n');
  const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
  for (const n of ["ic_launcher.xml", "ic_launcher_round.xml"]) {
    fs.mkdirSync(path.join(res, "mipmap-anydpi-v26"), { recursive: true });
    fs.writeFileSync(path.join(res, "mipmap-anydpi-v26", n), adaptive);
  }

  // 2) native launch screen: dark gradient + logo, matching the first frame of the in-app animation
  for (const d of fs.readdirSync(res)) {
    if (!d.startsWith("drawable")) continue;
    const dir = path.join(res, d);
    for (const f of fs.readdirSync(dir)) if (/^splash\.(png|webp|jpg|xml)$/.test(f)) fs.rmSync(path.join(dir, f));
  }
  copy(R("resources", "android", "drawable-nodpi", "splash_logo.png"), path.join(res, "drawable-nodpi", "splash_logo.png"));
  fs.mkdirSync(path.join(res, "drawable"), { recursive: true });
  fs.writeFileSync(path.join(res, "drawable", "splash.xml"),
    '<?xml version="1.0" encoding="utf-8"?>\n<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n' +
    '    <item><shape android:shape="rectangle"><gradient android:angle="270" android:startColor="#0B0D15" android:endColor="#1D2440"/></shape></item>\n' +
    '    <item android:gravity="center"><bitmap android:src="@drawable/splash_logo" android:gravity="center"/></item>\n</layer-list>\n');

  // 3) Android 12+ system splash background (only if the template uses the AndroidX splash theme)
  const styles = path.join(res, "values", "styles.xml");
  if (fs.existsSync(styles)) {
    let s = fs.readFileSync(styles, "utf8");
    if (s.includes("Theme.SplashScreen") && !s.includes("windowSplashScreenBackground")) {
      s = s.replace('<item name="android:background">@drawable/splash</item>',
        '<item name="android:background">@drawable/splash</item>\n        <item name="windowSplashScreenBackground">#0B0D15</item>');
      fs.writeFileSync(styles, s);
    }
  }
  console.log("Android icon + launch screen applied.");

} else if (platform === "ios") {
  const assets = R("ios", "App", "App", "Assets.xcassets");
  if (!fs.existsSync(assets)) { console.error("ios/ not found - run `npx cap add ios` first"); process.exit(1); }

  const icon = path.join(assets, "AppIcon.appiconset");
  fs.mkdirSync(icon, { recursive: true });
  for (const f of fs.readdirSync(icon)) if (f.endsWith(".png")) fs.rmSync(path.join(icon, f));
  copy(R("resources", "ios", "AppIcon-512@2x.png"), path.join(icon, "AppIcon-512@2x.png"));
  fs.writeFileSync(path.join(icon, "Contents.json"), JSON.stringify({
    images: [{ filename: "AppIcon-512@2x.png", idiom: "universal", platform: "ios", size: "1024x1024" }],
    info: { author: "xcode", version: 1 } }, null, 2) + "\n");

  const splash = path.join(assets, "Splash.imageset");
  if (fs.existsSync(splash)) walk(splash, (p) => { if (p.endsWith(".png")) copy(R("resources", "ios", "splash-2732x2732.png"), p); });
  console.log("iOS icon + launch screen applied.");
} else {
  console.error("usage: node scripts/apply-native-assets.mjs android|ios"); process.exit(1);
}
